CREATE PROCEDURE castActor (actorId IN INTEGER, movieId IN INTEGER, role IN Role.role%type) AS
foundactorId INTEGER;
foundmovieId INTEGER;
BEGIN

	SELECT ID INTO foundactorId FROM Actor A WHERE A.id = actorId;

	IF foundactorId IS NULL THEN
		dbms_output.put_line('Actor not found.');
	ELSE
		dbms_output.put_line('Actor found');

		SELECT ID INTO foundmovieId FROM Movie M WHERE M.id = movieId;

		IF foundmovieId IS NULL THEN
			dbms_output.put_line('Movie not found.');
		ELSE
			dbms_output.put_line('Movie found.');

			INSERT INTO Role VALUES (actorId, movieId, role);
		END IF;

	END IF;

END;
/
