CREATE TRIGGER INSERTROLE
BEFORE INSERT
  ON ROLE
FOR EACH ROW
  DECLARE
actorCastCount INTEGER;
movieCastCount INTEGER;
BEGIN

	SELECT COUNT(*) INTO actorCastCount FROM Role R WHERE R.actorId = :new.actorId AND R.movieId = :new.movieId;

	IF actorCastCount > 0 THEN
		RAISE_APPLICATION_ERROR(-20000, 'Actor/Actress ' || :new.actorId || ' already has a role in movie '
			|| :new.movieId || '!');
	END IF;

	SELECT COUNT(*) INTO movieCastCount FROM Role R WHERE R.movieId = :new.movieId;

	IF movieCastCount > 229 THEN
		RAISE_APPLICATION_ERROR(-20000, 'Movie ' || :new.movieId || ' has a full cast!');
	END IF;

END;
/
