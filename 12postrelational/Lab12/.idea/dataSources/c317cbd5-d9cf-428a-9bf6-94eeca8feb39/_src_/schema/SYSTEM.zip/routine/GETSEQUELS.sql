CREATE PROCEDURE getSequels (movieIdIn IN Movie.id%type) AS
-- Create temp cursor to iterate through the sequelIds
CURSOR temp IS
	SELECT sequelId FROM Movie WHERE id = movieIdIn;

-- Begin procedure code
BEGIN

	-- Remove all entries from the SequelsTemp table
	DELETE FROM SequelsTemp;

	-- Loop through the results from the temp cursor
	--		Recursively call getSequels on the sequel found
	--		Insert result into SequelsTemp
	FOR sequel IN temp LOOP
			getSequels(sequel.sequelId);
			INSERT INTO SequelsTemp (SELECT id, name FROM Movie WHERE id = sequel.sequelId);
	END LOOP;
END;
/
