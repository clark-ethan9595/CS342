CREATE PROCEDURE baconNumber (actorId_Base IN INTEGER, depthLevel IN INTEGER) AS

-- Local integer variables
inBaconTable INTEGER;
currentDepth INTEGER;
foundactorCount INTEGER;

BEGIN

	-- Check to see if the base actor is in the database
	SELECT COUNT(*) INTO foundactorCount FROM Actor WHERE id = actorId_Base;

	-- If base actor is not in the database, raise an application error
	IF foundactorCount = 0 THEN
		RAISE_APPLICATION_ERROR(-20000, 'Actor/Actress ' || actorId_Base || ' does not exist in database!');
	END IF;

	-- If first call of baconNumber, insert actorId with baconNumber 0
	IF depthLevel = 1 THEN
		INSERT INTO BaconTable VALUES (actorId_Base, 0);
	END IF;

	-- I don't go any deeper than 4 levels because without this condition, I get the error that says
	--		'maximum open cursors exceeded'. I tried setting the parameter for the total number of
	--		cursors I can have open, but that still didn't help the issue.
	IF depthLevel > 4 THEN
		RETURN;
	END IF;

	-- Iterate through the results from the cursor
	FOR actor IN (SELECT actorId FROM Role WHERE movieId IN (SELECT movieId FROM Role WHERE actorId = actorId_Base)) LOOP

		-- Find out if actor is already in the BaconTable
		SELECT COUNT(*) INTO inBaconTable FROM BaconTable WHERE actorId = actor.actorId;

		-- If actor is not in the BaconTable, insert into table
		IF inBaconTable = 0 THEN

			INSERT INTO BaconTable VALUES (actor.actorId, depthLevel);
			baconNumber(actor.actorId, depthLevel + 1);

		-- Otherwise check if we found a smaller baconNumber for that actor
		ELSE

			SELECT baconNumber INTO currentDepth FROM BaconTable WHERE actorId = actor.actorId;

			IF currentDepth > depthLevel THEN

				UPDATE BaconTable SET baconNumber = depthLevel WHERE actorId = actor.actorId;
				baconNumber(actor.actorId, depthLevel + 1);

			END IF;

		END IF;

	END LOOP;

END;
/
